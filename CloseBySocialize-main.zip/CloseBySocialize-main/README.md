Here is our Trello link : https://trello.com/b/zRvOgjof/grupp-1
