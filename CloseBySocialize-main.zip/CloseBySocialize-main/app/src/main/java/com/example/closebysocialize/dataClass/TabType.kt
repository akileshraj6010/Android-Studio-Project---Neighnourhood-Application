package com.example.closebysocialize.dataClass

enum class TabType {
    ALL_EVENTS,
    ATTENDING_EVENTS,
    SAVED_EVENTS
}
